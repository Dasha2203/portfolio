let columns = document.querySelector('#columns')


document.addEventListener('mousedown', function(event) {
    
    let card = event.target.closest('.wrapper-columns__card');
    if (!card) return;

    let shiftX = event.clientX - card.getBoundingClientRect().left;
    let shiftY = event.clientY - card.getBoundingClientRect().top;
    let oldDiv = document.createElement('div');
    oldDiv.classList.add('old-card'); 
    oldDiv.style.height =  card.offsetHeight + 'px';
    console.log(card.offsetHeight);
    card.after(oldDiv);

    card.style.position = 'absolute';
    card.style.zIndex = 1000;
    card.classList.add('draggable')
    document.body.append(card);
    moveAt(event.pageX, event.pageY);
    function moveAt(pageX, pageY) {
        card.style.left = pageX - shiftX + 'px';
        card.style.top = pageY - shiftY + 'px';
    }
    let currentDroppable = null;
    function onMouseMove(event) {
        
        moveAt(event.pageX, event.pageY);
        card.hidden = true;
        
        
    
        let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
        
        //card.hidden = false;
        if (!elemBelow) {
            return
        } else {
            //console.log('все ок')
        }
        let droppableBelow = elemBelow.closest('.wrapper-columns__item');
       
        if (currentDroppable != droppableBelow) {
    

    if (currentDroppable) {
        
        
    }
    currentDroppable = droppableBelow;
    if (currentDroppable) {
      console.log(currentDroppable)
    }
  }
    }
        
    document.addEventListener('mousemove',onMouseMove)
    document.onmouseup = function(event) {
        
        //console.log(currentDroppable)
        document.removeEventListener('mousemove', onMouseMove);
        document.onmouseup = null;
        card.classList.remove('draggable')
        //console.log('ура')
    };

    document.ondragstart = function() {
        return false;
    }; 
    
})